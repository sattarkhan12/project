
<?php

include "include/connection.php";



if(!empty($_POST['search'])){

  $search=$_POST['search'];
  $sql="SELECT item_id, item_name , item_price,item_date ,emp_name FROM items ,
   employess WHERE item_emp=emp_id and CONCAT(item_name,item_price,item_date ,emp_name) LIKE '%$search%'";
  mysqli_set_charset($c,"utf8");
  $result=mysqli_query($c,$sql);

  


}else{

  $sql="SELECT item_id, item_name , item_price,item_date ,emp_name FROM items , employess WHERE item_emp=emp_id";
  mysqli_set_charset($c,"utf8");
  $result=mysqli_query($c,$sql);

  
  
  
}




?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap  CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="boot/css/mycss.css">
  <title>invintory</title>
</head>

<body>

  <div class="container-fluid">
    <div class="row"  id="top"> 
      <div class="col-md-3">
       <img class="img-responsive" src="image/logo.png" alt="logo place">
      </div>
      <div class="col-md-6">
        
      </div>
      <div class="col-md-3">
        <h2 id="debt_name">خدمات نرم افزاری</h2>
      </div>
    </div>
    <br>

    <div class="row">
        <div class="col-md-4" id="menu">
          <ul class="nav nav-pills">
            <li class="nav-item">
              <a class="nav-link active" href="add_item.php">جنس جدید</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="add_emp.php">کامند جدید</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="list_emp.php">لیست کارمندان</a>
            </li>
            
          </ul>
        </div>

        <div class="col-md-6" id="fsearch">
            <form class="form-inline" action="" method="post">
                <div class="form-group">
                  <input type="text" class="form-control" name="search" placeholder="جستجو">

                  <button type="submit" class="btn btn-success"> جستجو</button>
                </div>
                
                
              </form>
        </div>

        <div class="col-md-2">
          <h2 class="title">لیست اجناس</h2>
        </div>

      </div>
      <br>

      <div class="row" id="content">
        <div class="col-md-12">
                  <table class="table table-striped" dir="rtl">
                    <thead>
                        <tr class="success">
                          <th>نام جنس</th>
                          <th>قیمت</th>
                          <th>تاریخ</th>
                          <th>کارمند</th>
                          <th>عملیات</th>

                        </tr>
                    </thead>
                    <TBODy>

                    <?php

                  
                   if(mysqli_num_rows($result)>0){
                      while($row=mysqli_fetch_row($result)){

                        echo "<tr>";
                            echo"<td>".$row[1]." </td>";
                            echo"<td>".$row[2]." </td>";
                            echo"<td>".$row[3]." </td>";
                            echo"<td>".$row[4]." </td>";
                            echo"<td><a href='edit_item.php?id=".$row[1]."'>اصلاح</a> </td>";

                        echo "<tr>";

                      }

                   }
                    
                    ?>


                     

                      
                    </TBODy>


                  </table>
        </div>
      </div>

  </div>








  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
    integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
    crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
    integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
    crossorigin="anonymous"></script>
</body>

</html>