
<?php

include "include/connection.php";

$name='';
$fname="";
$surname="";
$job="";
$id =$_GET['id'];

if(isset($_POST['subbtn'])){
  //update data

  if(!empty($_POST['name'])){
    $name=$_POST['name'];
  }
  if(!empty($_POST['fname'])){
    $fname=$_POST['fname'];
  }
  if(!empty($_POST['surname'])){
    $surname=$_POST['surname'];
  }
  if(!empty($_POST['job'])){
    $job=$_POST['job'];
  }
  
  $upsql="update employess set emp_name='$name',emp_fname='$fname',emp_surname='$surname',emp_job='$job' where emp_id=$id";
  
  if(mysqli_query($c,$upsql)){


    echo "موفقانه ویرایش شد ";
    header("location:list_emp.php");
  }else{
    echo "موفقانه اجرا نشد ";
    header("location:edit_emp.php?id=$id");
  }

}else{

  
   $sql="SELECT * FROM emplyess where emp_id=$id";
   $result=mysqli_query($c,$sql);
   $row=mysqli_fetch_row($result);
}



?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap  CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="boot/css/mycss.css">
  <title>invintory</title>
</head>

<body>

  <div class="container-fluid">
    <div class="row"  id="top"> 
      <div class="col-md-3">
      <img class="img-responsive" src="image/logo.png" alt="logo place">
      </div>
      <div class="col-md-6">
        
      </div>
      <div class="col-md-3">
        <h2 id="debt_name">خدمات نرم افزاری</h2>
      </div>
    </div>
    <br>

    <div class="row">
        <div class="col-md-4" id="menu">
          <ul class="nav nav-pills">
            <li class="nav-item">
              <a class="nav-link active" href="list_emp.php"> برگشت</a>
            </li>
          
          </ul>
        </div>

        

      </div>
      <br>

      <div class="row"  dir="rtl" id="content">
      <div class="col-md-12" >
          <h2 class="title" style="text-align: right;"> ویرایش کارمند</h2>

<br><br>

         
          <form  style="text-align: right;" action="" method="POST">
              <div class="form-group row" >
                <label for="inputEmail3"   class="col-sm-2 col-form-label">نام کامند</label>
                <div class="col-sm-10">
                  <input type="text" name="name" value="<?php if(!empty($row[1])){ echo $row[1]; } ?>"
                   class="form-control" id="inputEmail3" placeholder="نام کامند">
                </div>
              </div>

              <div class="form-group row">
                  <label for="inputEmail3" class="col-sm-2 col-form-label"> نام پدر</label>
                  <div class="col-sm-10">
                    <input type="text" name="fname" value="<?php if(!empty($row[1])){ echo $row[1]; } ?>"
                     class="form-control" id="inputEmail3" placeholder="نام پدر">
                  </div>
                </div>

                <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-2 col-form-label"> تخلص</label>
                    <div class="col-sm-10">
                      <input type="text" name="surname" value="<?php if(!empty($row[1])){ echo $row[1]; } ?>"
                       class="form-control" id="inputEmail3" placeholder="تخلص ">
                    </div>
                  </div>

                  <div class="form-group row">
                      <label for="inputEmail3" class="col-sm-2 col-form-label">وظیفه </label>
                      <div class="col-sm-10">
                        <input type="text" name="job" value="<?php if(!empty($row[1])){ echo $row[1]; } ?>"
                         class="form-control" id="inputEmail3" placeholder="وظیفه ">
                      </div>
                    </div>
             

              <div class="form-group row">
                  <div class="col-sm-10"></div>
                <div class="col-sm-2">
                  <button type="submit" name="subbtn" class="btn btn-primary btn-block"> ویرایش  </button>
                </div>
                
              </div>
            </form>
      



        

      </div>
      </div>

  </div>








  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
    integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
    crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
    integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
    crossorigin="anonymous"></script>
</body>

</html>