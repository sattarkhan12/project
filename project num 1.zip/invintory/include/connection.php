<?php
  
$c = mysqli_connect("localhost","root","","invintorys");

if(!$c){
    die("Connection not establashed ".mysqli_connect_error());
}

mysqli_set_charset($c,"utf8");
?>